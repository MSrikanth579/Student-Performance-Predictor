# Student Performance Predictor

A beginner-friendly machine-learning project that estimates a student's final score from study habits and academic indicators.

## Features
- Interactive web interface built with Streamlit
- Inputs: daily study hours, attendance, previous score, assignment completion, and sleep hours
- Random Forest Regression model
- Estimated score and a broad performance category
- Displays a simple model evaluation metric (MAE)

## Requirements
- Python 3.9 or newer
- Internet access to install the packages the first time

## Run on Windows
1. Install Python from https://www.python.org/downloads/ (enable **Add Python to PATH**).
2. Extract this project ZIP.
3. Open the extracted `student_performance_predictor` folder.
4. Click the File Explorer address bar, type `cmd`, and press Enter.
5. Run these commands one at a time:

```cmd
py -m venv .venv
.venv\\Scripts\\activate
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

6. Streamlit should open the app in your browser. If it prints a local URL, open that URL.

## Files
- `app.py` - application and model training code
- `student_data.csv` - sample training data (synthetic)
- `requirements.txt` - Python packages
- `README.md` - setup instructions

## Important note
The included data is synthetic/demo data, not real student records. The model is for learning and demonstration only. Do not use it to make high-stakes decisions about students. For a serious project, use appropriately collected, consented, representative data and evaluate fairness and accuracy carefully.
