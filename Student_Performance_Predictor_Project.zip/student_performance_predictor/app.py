import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from pathlib import Path

st.set_page_config(page_title="Student Performance Predictor", page_icon="🎓", layout="centered")

DATA_PATH = Path(__file__).parent / "student_data.csv"

@st.cache_resource
def train_model():
    data = pd.read_csv(DATA_PATH)
    features = ["study_hours", "attendance", "previous_score", "assignments_completed", "sleep_hours"]
    X = data[features]
    y = data["final_score"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = RandomForestRegressor(n_estimators=150, random_state=42)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    return model, mae, features

model, mae, features = train_model()

st.title("🎓 Student Performance Predictor")
st.write("Estimate a student's likely final score using study habits and previous academic information.")
st.info("This is an educational demo using sample data. Predictions are estimates, not guarantees.")

with st.form("prediction_form"):
    st.subheader("Enter student details")
    study_hours = st.slider("Average study hours per day", 0.0, 12.0, 3.0, 0.5)
    attendance = st.slider("Attendance (%)", 0, 100, 80, 1)
    previous_score = st.slider("Previous exam score (%)", 0, 100, 65, 1)
    assignments_completed = st.slider("Assignments completed (%)", 0, 100, 75, 1)
    sleep_hours = st.slider("Average sleep hours per night", 0.0, 12.0, 7.0, 0.5)
    submitted = st.form_submit_button("Predict performance")

if submitted:
    input_data = pd.DataFrame([{
        "study_hours": study_hours,
        "attendance": attendance,
        "previous_score": previous_score,
        "assignments_completed": assignments_completed,
        "sleep_hours": sleep_hours
    }])
    predicted_score = float(model.predict(input_data[features])[0])
    predicted_score = max(0.0, min(100.0, predicted_score))
    st.metric("Estimated final score", f"{predicted_score:.1f} / 100")
    if predicted_score >= 80:
        st.success("Estimated category: Excellent")
        st.write("Keep up consistent study habits and continue reviewing challenging topics.")
    elif predicted_score >= 60:
        st.success("Estimated category: Good / Satisfactory")
        st.write("A regular revision schedule and timely assignment completion may help.")
    else:
        st.warning("Estimated category: Needs support")
        st.write("Consider a study plan, attendance support, and help from a teacher or mentor.")
    st.caption("Use this estimate as a conversation starter, not as the sole basis for academic decisions.")

st.divider()
st.subheader("Model information")
st.write(f"Algorithm: Random Forest Regressor")
st.write(f"Mean Absolute Error on the held-out sample split: {mae:.2f} points")
st.caption("Performance metrics reflect the included synthetic sample dataset and may not generalize to real students.")
